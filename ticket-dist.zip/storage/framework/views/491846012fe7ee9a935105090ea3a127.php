<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Update Ticket
        </h2>
     <?php $__env->endSlot(); ?>
    
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <?php if(session()->has('message')): ?>
                    <p class="text-red">
                        <?php echo e(session()->get('message')); ?>

                    </p>
                    <?php endif; ?>
                    
                    <form action="<?php echo e(route('tickets.update',  $ticket)); ?>" method="post" class="max-w-sm mx-auto" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>;
                        <div class="mb-5">
                            <label for="title" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Ticket Title</label>
                            <input type="text" name="ticket_title" id="title" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Ticket title" value="<?php echo e($ticket->ticket_title); ?>" disabled>
                            <?php if($errors->has('ticket_title')): ?>
                            <div class="text-red-400"><?php echo e($errors->first('ticket_title')); ?></div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="mb-5">
                            <label for="ticket_status" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Ticket Status</label>
                            
                            <div class="flex items-center mb-4">
                                <input id="pending" type="radio" name="ticket_status" value="pending" class="w-4 h-4 border-gray-300 focus:ring-2 focus:ring-blue-300 dark:focus:ring-blue-600 dark:focus:bg-blue-600 dark:bg-gray-700 dark:border-gray-600" <?php echo e($ticket->status == 'pending' ? 'checked' : ''); ?>>
                                <label for="pending" class="block ms-2  text-sm font-medium text-gray-900 dark:text-gray-300">
                                    Pending
                                </label>
                            </div>
                            
                            <div class="flex items-center mb-4">
                                <input id="in-progress" type="radio" name="ticket_status" value="in-progress" class="w-4 h-4 border-gray-300 focus:ring-2 focus:ring-blue-300 dark:focus:ring-blue-600 dark:focus:bg-blue-600 dark:bg-gray-700 dark:border-gray-600" <?php echo e($ticket->status == 'in-progress' ? 'checked' : ''); ?>>
                                <label for="in-progress" class="block ms-2 text-sm font-medium text-gray-900 dark:text-gray-300">
                                    In Progress
                                </label>
                            </div>
                            
                            <div class="flex items-center mb-4">
                                <input id="close" type="radio" name="ticket_status" value="close" class="w-4 h-4 border-gray-300 focus:ring-2 focus:ring-blue-300 dark:focus:ring-blue-600 dark:focus:bg-blue-600 dark:bg-gray-700 dark:border-gray-600" <?php echo e($ticket->status == 'close' ? 'checked' : ''); ?>>
                                <label for="close" class="block ms-2 text-sm font-medium text-gray-900 dark:text-gray-300">
                                    Close
                                </label>
                            </div>
                            <?php if($errors->has('ticket_status')): ?>
                            <div class="text-red-400	"><?php echo e($errors->first('ticket_status')); ?></div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="mb-5">
                            <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-white" for="ticket_image">Upload file</label>
                            <input class="block w-full text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-gray-50 dark:text-gray-400 focus:outline-none dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400" aria-describedby="user_avatar_help" id="ticket_image" type="file" name="ticket_image">
                            <?php if($errors->has('ticket_image')): ?>
                            <div class="text-red-400	"><?php echo e($errors->first('ticket_image')); ?></div>
                            <?php endif; ?>
                        </div>
                        
                        <button type="submit" class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Submit</button>
                    </form>
                    
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ticket-dist\resources\views/tickets/edit.blade.php ENDPATH**/ ?>